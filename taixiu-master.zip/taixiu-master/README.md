THÔNG TIN CHUNG:

- Realtime sử dụng socket.io.

- Server chịu được lượng user lớn.

- Code thiết kế bằng mã nguồn mở Html, NodeJS
 
- Dễ chỉnh sửa, không cần biết nhiều về code 
  
- Hạn chế tối đa việc sử dụng plugin,module nhằm tránh ảnh hưởng tới tốc độ tải trang.
 
- Code sạch, đảm bảo ko có mã độc.
 
- Code đơn giản dễ đọc, chú thích rõ ràng .
 
- Các tính năng như Web game tài xỉu hiện tại.

CHÚ THÍCH:

- Đây là code để học hỏi nên mình chưa code phần login, cân kèo, bạn nào muốn phát triển thì code thêm nhé, code chủ yếu là tập trung vào tính năng server game tài xỉu nên mình code client bằng html cho các bạn dễ đọc, chứ nếu muốn code 1 project client như các web hiện tại thì nên dùng cocos2d ([Link trang chủ](https://cocos2d-x.org)), code 1 lần có thể build ra cho web, window, android, ios, linux, macOS sử dụng, có các công cụ hỗ trợ việc tạo game đơn giản, code bằng JS nên đỡ nhầm lẫn code giữa lúc code client và server.

- Mình chưa code phần login nên các bạn mở mỗi tab sẽ tính như là 1 user nhé.

- Như đã nói ở trên thì code này mục đích chính là học hỏi, nên bạn nào lấy đi phát triển thương mại hay gì bị túm thì mình không chịu trách nhiệm nhé.

- Ai copy code xin ghi nguồn: [Nhockm4v](https://www.facebook.com/nhockm4v)



DEMO ONLINE: https://taixiu.herokuapp.com/

HÌNH ẢNH DEMO:
![alt text](https://i.imgur.com/3WtlX1l.png)
![alt text](https://i.imgur.com/XJXS1il.png)

